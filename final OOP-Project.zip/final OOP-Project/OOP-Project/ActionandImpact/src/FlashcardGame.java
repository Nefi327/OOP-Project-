/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class FlashcardGame extends javax.swing.JFrame {

    private List<Flashcard> flashcards;
    private List<Flashcard> currentDeck;
    private int currentCardIndex;
    private int score;
    private boolean showingTerm;

    private Timer flipTimer;
    private int flipAngle = 0;
    private boolean flipping = false;
    private String currentTerm = "";
    private String currentDescription = "";
    

    public FlashcardGame() {
        
    initComponents();
    getContentPane().removeAll();
    getContentPane().setLayout(new BorderLayout());

    // Top panel labels
    JPanel topPanel = new JPanel();
    topPanel.add(backButton);
    topPanel.add(jLabel1);
    topPanel.add(ProgressLabel);
    topPanel.add(scoreLabel);
    getContentPane().add(topPanel, BorderLayout.NORTH);

    //  panel (flashcard display)
    JPanel1.setLayout(new BorderLayout());
    getContentPane().add(JPanel1, BorderLayout.CENTER);

    // Bottom panel buttons
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(flipButton);
    buttonPanel.add(nextButton);
    buttonPanel.add(knowButton);
    buttonPanel.add(dontKnowButton);
    getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    setSize(620, 470);
    setMinimumSize(new Dimension(300, 320));

  
    initializeFlashcards();
    setupEventHandlers();
    showNextCard();

    pack();
    setLocationRelativeTo(null);
}

    private void initializeFlashcards() {
       flashcards = new ArrayList<>();

    flashcards.add(new Flashcard(
        "Coral Reef Ecosystem",
        "Coral reefs cover less than 1% of the ocean floor but support about 25% of all marine species. "
        + "They are built by tiny coral polyps that secrete calcium carbonate, forming intricate reef structures "
        + "that provide habitat and protection for fish, crustaceans, and algae. Healthy reefs also act as natural "
        + "barriers, protecting coastlines from storms and erosion."
    ));

    flashcards.add(new Flashcard(
        "Bioluminescent Organisms",
        "Many deep-sea creatures produce their own light through chemical reactions in their bodies, a phenomenon "
        + "called bioluminescence. This adaptation helps them attract prey, communicate, or hide from predators "
        + "in the dark depths of the ocean where sunlight doesn’t reach."
    ));

    flashcards.add(new Flashcard(
        "Mangrove Forests",
        "Mangroves grow in coastal tropical areas and are specially adapted to salty, waterlogged soils. "
        + "Their complex root systems stabilize shorelines, prevent erosion, and serve as nurseries for juvenile fish "
        + "and crustaceans, supporting coastal biodiversity."
    ));

    flashcards.add(new Flashcard(
        "Kelp Forests",
        "Kelp forests are underwater canopies formed by large brown algae. They provide shelter and food for countless "
        + "marine species, including sea otters, fish, and invertebrates. Kelp forests also absorb carbon dioxide efficiently, "
        + "helping regulate oceanic carbon levels and fight climate change."
    ));

    flashcards.add(new Flashcard(
        "Deep-Sea Hydrothermal Vents",
        "Hydrothermal vents occur where tectonic plates meet on the ocean floor, releasing superheated water rich in minerals. "
        + "These vents support unique ecosystems, including tube worms, clams, and bacteria that rely on chemosynthesis "
        + "instead of sunlight for energy."
    ));

    flashcards.add(new Flashcard(
        "Seagrass Meadows",
        "Seagrass meadows are flowering plants found in shallow coastal waters. They act as nurseries for young fish and invertebrates, "
        + "stabilize sediments, filter pollutants, and store carbon at rates comparable to tropical forests, making them critical "
        + "for ocean health."
    ));

        currentDeck = new ArrayList<>(flashcards);
        Collections.shuffle(currentDeck);
        currentCardIndex = 0;
        score = 0;
        showingTerm = true;
    }
    
    private void setupEventHandlers() {
        flipButton.addActionListener(e -> startFlipAnimation());
        nextButton.addActionListener(e -> showNextCard());
        knowButton.addActionListener(e -> markAsKnown());
        dontKnowButton.addActionListener(e -> markAsUnknown());
        backButton.addActionListener(e -> {
            new GameManager().setVisible(true);
            dispose();
        });

        JPanel1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                startFlipAnimation();
            }
        });
    }

    private void showNextCard() {
        if (currentCardIndex < currentDeck.size()) {
            Flashcard currentCard = currentDeck.get(currentCardIndex);
            currentTerm = currentCard.getTerm();
            currentDescription = currentCard.getDescription();

            scoreLabel.setText("Card: " + (currentCardIndex + 1) + "/" + currentDeck.size());
            showCardFront();
            showingTerm = true;
            flipButton.setEnabled(true);
            knowButton.setEnabled(false);
            dontKnowButton.setEnabled(false);
        } else {
            endGame();
        }
    }

    private void showCardFront() {
    JPanel1.removeAll();

    JPanel frontPanel = new JPanel(new BorderLayout());
    frontPanel.setBackground(new Color(173, 216, 230));
    frontPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 3));

    JLabel termLabel = new JLabel("<html><center>" + currentTerm + "</center></html>", SwingConstants.CENTER);
    termLabel.setFont(new Font("Arial", Font.BOLD, 28));

    JLabel instructionLabel = new JLabel("Click to flip", SwingConstants.CENTER);
    instructionLabel.setFont(new Font("Arial", Font.ITALIC, 14));

    frontPanel.add(termLabel, BorderLayout.CENTER);
    frontPanel.add(instructionLabel, BorderLayout.SOUTH);

    JPanel1.add(frontPanel, BorderLayout.CENTER);
    JPanel1.revalidate();
    JPanel1.repaint();
}

private void showCardBack() {
    JPanel1.removeAll();

    JPanel backPanel = new JPanel(new BorderLayout());
    backPanel.setBackground(new Color(144, 238, 144));
    backPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 3));

    JTextArea descArea = new JTextArea(currentDescription);
    descArea.setFont(new Font("Arial", Font.PLAIN, 16));
    descArea.setWrapStyleWord(true);
    descArea.setLineWrap(true);
    descArea.setEditable(false);
    descArea.setBackground(new Color(144, 238, 144));

    
    int lines = currentDescription.split("\n").length + currentDescription.length() / 50;
    descArea.setRows(Math.max(lines, 10)); // Minimum 10 rows
    descArea.setColumns(40);

    backPanel.add(descArea, BorderLayout.CENTER);

    JPanel1.add(backPanel, BorderLayout.CENTER);
    JPanel1.revalidate();
    JPanel1.repaint();
}


    private void startFlipAnimation() {
        if (flipping) return;

        flipping = true;
        flipAngle = 0;

        flipTimer = new Timer(10, e -> {
            flipAngle += 18;

            if (flipAngle >= 180) {
                flipTimer.stop();
                flipping = false;

                if (showingTerm) {
                    showCardBack();
                    showingTerm = false;
                    knowButton.setEnabled(true);
                    dontKnowButton.setEnabled(true);
                } else {
                    showCardFront();
                    showingTerm = true;
                    knowButton.setEnabled(false);
                    dontKnowButton.setEnabled(false);
                }
            }
            JPanel1.repaint();
        });

        flipTimer.start();
    }

    private void markAsKnown() {
        score += 10;
        scoreLabel.setText("Score: " + score);
        currentCardIndex++;
        showNextCard();
    }
    
    private void markAsUnknown() {
        Flashcard currentCard = currentDeck.get(currentCardIndex);
        currentDeck.add(currentCard);
        currentCardIndex++;
        showNextCard();
    }

    private void endGame() {
        JOptionPane.showMessageDialog(
            this,
            "Session complete!\nScore: " + score,
            "Flashcards",
            JOptionPane.INFORMATION_MESSAGE
        );

        initializeFlashcards();
        showNextCard();
    }
        
    public int getScore() {
    return score;
}
           

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JPanel1 = new javax.swing.JPanel();
        flipButton = new javax.swing.JButton();
        nextButton = new javax.swing.JButton();
        knowButton = new javax.swing.JButton();
        dontKnowButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        ProgressLabel = new javax.swing.JLabel();
        scoreLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        JPanel1.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout JPanel1Layout = new javax.swing.GroupLayout(JPanel1);
        JPanel1.setLayout(JPanel1Layout);
        JPanel1Layout.setHorizontalGroup(
            JPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        JPanel1Layout.setVerticalGroup(
            JPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        flipButton.setText("Flip");

        nextButton.setText("Next");

        knowButton.setText("Learned");

        dontKnowButton.setText("To be Learned");

        backButton.setText("Back");

        jLabel1.setText("Flashcard");

        ProgressLabel.setText("Score");

        scoreLabel.setText("0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ProgressLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(scoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(JPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(122, 122, 122))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(flipButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(nextButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76)
                        .addComponent(knowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(dontKnowButton)))
                .addContainerGap(107, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ProgressLabel)
                            .addComponent(scoreLabel)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(backButton)
                            .addComponent(jLabel1))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 391, Short.MAX_VALUE)
                .addComponent(JPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(flipButton)
                    .addComponent(nextButton)
                    .addComponent(knowButton)
                    .addComponent(dontKnowButton))
                .addGap(33, 33, 33))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FlashcardGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FlashcardGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FlashcardGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FlashcardGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FlashcardGame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel JPanel1;
    private javax.swing.JLabel ProgressLabel;
    private javax.swing.JButton backButton;
    private javax.swing.JButton dontKnowButton;
    private javax.swing.JButton flipButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton knowButton;
    private javax.swing.JButton nextButton;
    private javax.swing.JLabel scoreLabel;
    // End of variables declaration//GEN-END:variables
}
