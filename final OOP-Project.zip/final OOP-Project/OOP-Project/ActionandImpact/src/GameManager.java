import javax.swing.*;
import java.awt.event.*;

/**
 * @author bxstx
 */
public class GameManager extends javax.swing.JFrame {
    
    private CrosswordGame crosswordGame;
    private FlashcardGame flashcardGame;
    private int totalScore = 0;

    public GameManager() {
        initComponents();
        setupEventHandlers();
    }
    
    private void setupEventHandlers() {
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(
                    GameManager.this,
                    "Are you sure you want to exit?",
                    "Exit Confirmation",
                    JOptionPane.YES_NO_OPTION
                );
                
                if (choice == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        
        btnBackToLanding.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LandingPage landing = new LandingPage();
                landing.setVisible(true);
                GameManager.this.dispose();
            }
        });
    }
    
    public void startCrossword() {
        if (crosswordGame == null || !crosswordGame.isVisible()) {
            crosswordGame = new CrosswordGame();
            crosswordGame.setLocationRelativeTo(this);
            crosswordGame.setVisible(true);
        } else {
            crosswordGame.toFront();
        }
    }
    
    public void startFlashcard() {
        if (flashcardGame == null || !flashcardGame.isVisible()) {
            flashcardGame = new FlashcardGame();
            flashcardGame.setLocationRelativeTo(this);
            flashcardGame.setVisible(true);
        } else {
            flashcardGame.toFront();
        }
    }
    
    public int getCrosswordScore() {
        if (crosswordGame != null) {
            return crosswordGame.getScore();
        }
        return 0;
    }
    
    public int getFlashcardScore() {
        if (flashcardGame != null) {
            return flashcardGame.getScore();
        }
        return 0;
    }
    
    public int getTotalScore() {
        return getCrosswordScore() + getFlashcardScore();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        crosswordgameBtn = new javax.swing.JButton();
        flashcardgameBtn = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnBackToLanding = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Game Manager");

        jLabel3.setText("Game Manager");
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18));

        crosswordgameBtn.setText("Crossword Game");
        crosswordgameBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crosswordgameBtnActionPerformed(evt);
            }
        });

        flashcardgameBtn.setText("Flashcard Game");
        flashcardgameBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flashcardgameBtnActionPerformed(evt);
            }
        });

        btnBack.setText("Exit");
        btnBackToLanding.setText("Back");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(crosswordgameBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                .addComponent(flashcardgameBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnBackToLanding)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(170, 170, 170))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(crosswordgameBtn)
                    .addComponent(flashcardgameBtn))
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBackToLanding)
                    .addComponent(btnBack))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }
    
    private void flashcardgameBtnActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        startFlashcard();
    }                                                

    private void crosswordgameBtnActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        startCrossword();
    }                                                

    // Variables declaration
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBackToLanding;
    private javax.swing.JButton crosswordgameBtn;
    private javax.swing.JButton flashcardgameBtn;
    private javax.swing.JLabel jLabel3;
}
