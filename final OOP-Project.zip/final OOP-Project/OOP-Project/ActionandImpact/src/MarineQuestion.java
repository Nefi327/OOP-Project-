

/**
 *
 * @author zacca
 */
public class MarineQuestion {
    private String text;
    private String correctAnswer;

    public MarineQuestion(String text, String correctAnswer) {
        this.text = text;
        this.correctAnswer = correctAnswer;
    }

    public String getText() {
        return text;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
}
