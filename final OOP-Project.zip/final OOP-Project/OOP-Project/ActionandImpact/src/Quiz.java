

/**
 *
 * @author zacca
 */
public class Quiz {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                KnowledgeAssessmentFrame frame = new KnowledgeAssessmentFrame();
                frame.setLocationRelativeTo(null); 
                frame.setAlwaysOnTop(true);         
                frame.setVisible(true);
            }
        });

      
    }
}
