public class CrosswordClue {
    private String definition;
    private String answer;
    private int row;
    private int col;
    private String direction;

    public CrosswordClue(String definition, String answer, int row, int col, String direction) {
        this.definition = definition;
        this.answer = answer;
        this.row = row;
        this.col = col;
        this.direction = direction;
    }

    public String getDefinition() { return definition; }
    public String getAnswer() { return answer; }
    public int getRow() { return row; }
    public int getCol() { return col; }
    public String getDirection() { return direction; }
    public int getLength() { return answer.length(); }

    public boolean isCorrect(String userAnswer) {
        return answer.equalsIgnoreCase(userAnswer.trim());
    }
}