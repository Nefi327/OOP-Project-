/**
 *
 * @author Fabian.S
 */
public class MainApp {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new LandingPage().setVisible(true);
            
            LandingPage frame = new LandingPage();
        frame.setSize(600, 400); // or whatever size you want
        frame.setLocationRelativeTo(null); // center on screen
        frame.setVisible(true);

        });
    }
}
