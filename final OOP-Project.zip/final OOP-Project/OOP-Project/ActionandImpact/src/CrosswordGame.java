import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class CrosswordGame extends javax.swing.JFrame {
    
    private List<CrosswordClue> clues;
    private JTextField[][] grid;
    private int score = 0;
    private int timeLeftSeconds = 600;
    private Timer timer;
    private static final int GRID_SIZE = 15;

    public CrosswordGame() {
        initComponents();
        initializeGame();
        setupEventHandlers();
        setLocationRelativeTo(null);
    }
    
    private void initializeGame() {
        clues = new ArrayList<>();
        
        // ACROSS clues with proper crossword layout
        clues.add(new CrosswordClue("Large singing marine mammal (5)", "WHALE", 1, 1, "ACROSS"));
        clues.add(new CrosswordClue("Colorful underwater ecosystem (5)", "CORAL", 3, 5, "ACROSS"));
        clues.add(new CrosswordClue("Intelligent marine mammal (7)", "DOLPHIN", 5, 2, "ACROSS"));
        clues.add(new CrosswordClue("Ancient marine reptile (6)", "TURTLE", 7, 8, "ACROSS"));
        clues.add(new CrosswordClue("Ocean predator (5)", "SHARK", 9, 3, "ACROSS"));
        clues.add(new CrosswordClue("Microscopic marine plants (8)", "PLANKTON", 11, 1, "ACROSS"));
        
        // DOWN clues
        clues.add(new CrosswordClue("Underwater flowering plant (8)", "SEAGRASS", 1, 1, "DOWN"));
        clues.add(new CrosswordClue("Coastal saltwater trees (8)", "MANGROVE", 1, 5, "DOWN"));
        clues.add(new CrosswordClue("Eight-armed cephalopod (7)", "OCTOPUS", 1, 9, "DOWN"));
        clues.add(new CrosswordClue("Gelatinous sea creature (9)", "JELLYFISH", 3, 12, "DOWN"));
        clues.add(new CrosswordClue("Marine algae (4)", "KELP", 5, 14, "DOWN"));

        initializeGrid();
        startTimer();
    }
    
    private void initializeGrid() {
        mainPanel.removeAll();
        mainPanel.setLayout(new GridLayout(GRID_SIZE, GRID_SIZE, 0, 0));
        grid = new JTextField[GRID_SIZE][GRID_SIZE];
        
        // Create black squares and white squares
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                boolean isBlack = true;
                
                // Check if this cell is part of any clue
                for (CrosswordClue clue : clues) {
                    if (clue.getDirection().equals("ACROSS")) {
                        if (i == clue.getRow() && j >= clue.getCol() && j < clue.getCol() + clue.getLength()) {
                            isBlack = false;
                            break;
                        }
                    } else { // DOWN
                        if (j == clue.getCol() && i >= clue.getRow() && i < clue.getRow() + clue.getLength()) {
                            isBlack = false;
                            break;
                        }
                    }
                }
                
                if (isBlack) {
                    JPanel blackPanel = new JPanel();
                    blackPanel.setBackground(Color.BLACK);
                    mainPanel.add(blackPanel);
                } else {
                    // Create a text field for white squares
                    grid[i][j] = new JTextField();
                    grid[i][j].setHorizontalAlignment(JTextField.CENTER);
                    grid[i][j].setFont(new Font("Arial", Font.BOLD, 18));
                    grid[i][j].setBackground(Color.WHITE);
                    grid[i][j].setForeground(Color.BLACK);
                    grid[i][j].setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
                    
                    // Add small clue number in corner
                    int clueNumber = getClueNumber(i, j);
                    if (clueNumber > 0) {
                        JPanel cellPanel = new JPanel(new BorderLayout());
                        cellPanel.setBackground(Color.WHITE);
                        cellPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
                        
                        JLabel numberLabel = new JLabel(String.valueOf(clueNumber));
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 10));
                        numberLabel.setForeground(Color.BLACK);
                        numberLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 0, 0));
                        cellPanel.add(numberLabel, BorderLayout.NORTH);
                        
                        cellPanel.add(grid[i][j], BorderLayout.CENTER);
                        mainPanel.add(cellPanel);
                    } else {
                        mainPanel.add(grid[i][j]);
                    }
                    
                    final int row = i;
                    final int col = j;
                    grid[i][j].addKeyListener(new KeyAdapter() {
                        @Override
                        public void keyTyped(KeyEvent e) {
                            if (grid[row][col].getText().length() >= 1) {
                                e.consume();
                            } else {
                                char c = e.getKeyChar();
                                if (Character.isLetter(c)) {
                                    grid[row][col].setText(String.valueOf(c).toUpperCase());
                                    // Auto-move to next cell
                                    moveToNextCell(row, col);
                                }
                                e.consume();
                            }
                        }
                    });
                }
            }
        }
        
        mainPanel.revalidate();
        mainPanel.repaint();
    }
    
    private int getClueNumber(int row, int col) {
        int number = 0;
        for (int i = 0; i < clues.size(); i++) {
            CrosswordClue clue = clues.get(i);
            if (clue.getRow() == row && clue.getCol() == col) {
                return i + 1;
            }
        }
        return 0;
    }
    
    private void moveToNextCell(int row, int col) {
        // Try to move right (ACROSS)
        for (CrosswordClue clue : clues) {
            if (clue.getDirection().equals("ACROSS")) {
                if (row == clue.getRow() && col >= clue.getCol() && col < clue.getCol() + clue.getLength() - 1) {
                    if (grid[row][col + 1] != null) {
                        grid[row][col + 1].requestFocus();
                        return;
                    }
                }
            }
        }
        
        // Try to move down (DOWN)
        for (CrosswordClue clue : clues) {
            if (clue.getDirection().equals("DOWN")) {
                if (col == clue.getCol() && row >= clue.getRow() && row < clue.getRow() + clue.getLength() - 1) {
                    if (grid[row + 1][col] != null) {
                        grid[row + 1][col].requestFocus();
                        return;
                    }
                }
            }
        }
    }
    
    private void startTimer() {
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timeLeftSeconds > 0) {
                    timeLeftSeconds--;
                    int minutes = timeLeftSeconds / 60;
                    int seconds = timeLeftSeconds % 60;
                    timerLabel.setText(String.format("Time: %02d:%02d", minutes, seconds));
                } else {
                    timer.stop();
                    checkAnswers();
                    JOptionPane.showMessageDialog(CrosswordGame.this, 
                        "Time's up! Final Score: " + score);
                }
            }
        });
        timer.start();
    }
    
    private void checkAnswers() {
        int correctCount = 0;
        boolean allCorrect = true;
        
        for (CrosswordClue clue : clues) {
            String userAnswer = getUserAnswer(clue);
            boolean isCorrect = clue.isCorrect(userAnswer);
            
            if (isCorrect) {
                correctCount++;
                highlightAnswer(clue, new Color(144, 238, 144)); // Green
            } else {
                allCorrect = false;
                highlightAnswer(clue, new Color(255, 182, 193)); // Pink
            }
        }
        
        score = correctCount * 10;
        scoreLabel.setText("Score: " + score);
        
        if (allCorrect) {
            timer.stop();
            JOptionPane.showMessageDialog(this, 
                "Congratulations! All answers correct!\nFinal Score: " + score,
                "Puzzle Complete!", 
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "You have " + correctCount + " out of " + clues.size() + " correct.\n" +
                "Score: " + score + "\n\n" +
                "Green: Correct answers\nPink: Incorrect answers",
                "Progress Update", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private String getUserAnswer(CrosswordClue clue) {
        StringBuilder userAnswer = new StringBuilder();
        int row = clue.getRow();
        int col = clue.getCol();
        
        if (clue.getDirection().equals("ACROSS")) {
            for (int i = 0; i < clue.getLength(); i++) {
                if (col + i < GRID_SIZE && grid[row][col + i] != null) {
                    String text = grid[row][col + i].getText();
                    userAnswer.append(text.isEmpty() ? " " : text);
                }
            }
        } else { // DOWN
            for (int i = 0; i < clue.getLength(); i++) {
                if (row + i < GRID_SIZE && grid[row + i][col] != null) {
                    String text = grid[row + i][col].getText();
                    userAnswer.append(text.isEmpty() ? " " : text);
                }
            }
        }
        return userAnswer.toString().trim().toUpperCase();
    }
    
    private void highlightAnswer(CrosswordClue clue, Color color) {
        int row = clue.getRow();
        int col = clue.getCol();
        
        if (clue.getDirection().equals("ACROSS")) {
            for (int i = 0; i < clue.getLength(); i++) {
                if (col + i < GRID_SIZE && grid[row][col + i] != null) {
                    grid[row][col + i].setBackground(color);
                    grid[row][col + i].setForeground(Color.BLACK);
                    if (color == new Color(144, 238, 144)) {
                        grid[row][col + i].setEditable(false);
                    }
                }
            }
        } else { // DOWN
            for (int i = 0; i < clue.getLength(); i++) {
                if (row + i < GRID_SIZE && grid[row + i][col] != null) {
                    grid[row + i][col].setBackground(color);
                    grid[row + i][col].setForeground(Color.BLACK);
                    if (color == new Color(144, 238, 144)) {
                        grid[row + i][col].setEditable(false);
                    }
                }
            }
        }
    }
    
    private void showClues() {
        StringBuilder clueText = new StringBuilder();
        clueText.append("=== ACROSS ===\n");
        
        for (int i = 0; i < clues.size(); i++) {
            CrosswordClue clue = clues.get(i);
            if (clue.getDirection().equals("ACROSS")) {
                clueText.append(i + 1).append(". ").append(clue.getDefinition())
                       .append(" (").append(clue.getLength()).append(" letters)\n");
            }
        }
        
        clueText.append("\n=== DOWN ===\n");
        for (int i = 0; i < clues.size(); i++) {
            CrosswordClue clue = clues.get(i);
            if (clue.getDirection().equals("DOWN")) {
                clueText.append(i + 1).append(". ").append(clue.getDefinition())
                       .append(" (").append(clue.getLength()).append(" letters)\n");
            }
        }
        
        clueText.append("\nInstructions:\n");
        clueText.append("• Click in any white square and type letters\n");
        clueText.append("• Press Enter to move to next cell\n");
        clueText.append("• Correct answers turn green\n");
        clueText.append("• Incorrect answers turn pink");

        JOptionPane.showMessageDialog(this, clueText.toString(), "Crossword Clues", 
                                    JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void setupEventHandlers() {
        showCluesButton.addActionListener(e -> showClues());
        checkButton.addActionListener(e -> checkAnswers());
        backButton.addActionListener(e -> {
            if (timer != null) {
                timer.stop();
            }
            new GameManager().setVisible(true);
            dispose();
        });
    }
    
    public int getScore() {
        return score;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     */
    private void initComponents() {
        mainPanel = new javax.swing.JPanel();
        showCluesButton = new javax.swing.JButton();
        checkButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        scoreLabel = new javax.swing.JLabel();
        timerLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Marine Life Crossword - SDG 14");

        mainPanel.setBackground(new java.awt.Color(240, 248, 255));
        mainPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setLayout(new java.awt.GridLayout(15, 15));

        showCluesButton.setText("Show Clues");
        showCluesButton.setFont(new java.awt.Font("Segoe UI", 1, 14));
        showCluesButton.setForeground(java.awt.Color.BLACK);

        checkButton.setText("Check Answers");
        checkButton.setFont(new java.awt.Font("Segoe UI", 1, 14));
        checkButton.setForeground(java.awt.Color.BLACK);

        backButton.setText("Back to Menu");
        backButton.setFont(new java.awt.Font("Segoe UI", 1, 14));
        backButton.setForeground(java.awt.Color.BLACK);

        scoreLabel.setText("Score: 0");
        scoreLabel.setFont(new java.awt.Font("Segoe UI", 1, 16));
        scoreLabel.setForeground(java.awt.Color.BLACK);

        timerLabel.setText("Time: 10:00");
        timerLabel.setFont(new java.awt.Font("Segoe UI", 1, 16));
        timerLabel.setForeground(java.awt.Color.BLACK);

        titleLabel.setFont(new java.awt.Font("Segoe UI", 1, 24));
        titleLabel.setForeground(java.awt.Color.BLACK);
        titleLabel.setText("Marine Life Crossword Puzzle");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(titleLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(timerLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(scoreLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(showCluesButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(checkButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(backButton)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titleLabel)
                    .addComponent(timerLabel)
                    .addComponent(scoreLabel))
                .addGap(18, 18, 18)
                .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(showCluesButton)
                    .addComponent(checkButton)
                    .addComponent(backButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrosswordGame().setVisible(true);
            }
        });
    }

    // Variables declaration
    private javax.swing.JButton backButton;
    private javax.swing.JButton checkButton;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JButton showCluesButton;
    private javax.swing.JLabel scoreLabel;
    private javax.swing.JLabel timerLabel;
    private javax.swing.JLabel titleLabel;
    // End of variables declaration
}